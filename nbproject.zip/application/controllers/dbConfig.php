<?php

class DBConfig {

    //define databases and tables

    CONST TABLE_USERS = 'users';
    CONST ATT_USERS_ID = 'user_id';
    CONST ATT_USERS_NAME = 'name';
    CONST ATT_USERS_STATE = 'state';
    CONST ATT_USERS_USER_TYPE = 'user_type';
    CONST ATT_USERS_TYPE = 'type';

}
