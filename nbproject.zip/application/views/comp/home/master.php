<div class="panel panel-primary">

    <div class="panel-heading">
        <h3 class="panel-title">Dashboard</h3>
    </div>

    <div class="panel-body">

        <h1>Dashboard</h1>

    </div>
    <div class="panel-footer">Developed By Winexsoft Technology</div>
</div>
